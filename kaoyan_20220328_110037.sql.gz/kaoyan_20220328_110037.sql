-- MySQL dump 10.13  Distrib 5.5.62, for Linux (x86_64)
--
-- Host: localhost    Database: kaoyan
-- ------------------------------------------------------
-- Server version	5.5.62-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_menu`
--

DROP TABLE IF EXISTS `admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_menu`
--

LOCK TABLES `admin_menu` WRITE;
/*!40000 ALTER TABLE `admin_menu` DISABLE KEYS */;
INSERT INTO `admin_menu` VALUES (1,0,1,'Dashboard','fa-bar-chart','/',NULL,NULL,NULL),(2,0,2,'Admin','fa-tasks','',NULL,NULL,NULL),(3,2,3,'Users','fa-users','auth/users',NULL,NULL,NULL),(4,2,4,'Roles','fa-user','auth/roles',NULL,NULL,NULL),(5,2,5,'Permission','fa-ban','auth/permissions',NULL,NULL,NULL),(6,2,6,'Menu','fa-bars','auth/menu',NULL,NULL,NULL),(7,2,7,'Operation log','fa-history','auth/logs',NULL,NULL,NULL);
/*!40000 ALTER TABLE `admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_operation_log`
--

DROP TABLE IF EXISTS `admin_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_operation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_operation_log_user_id_index` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_operation_log`
--

LOCK TABLES `admin_operation_log` WRITE;
/*!40000 ALTER TABLE `admin_operation_log` DISABLE KEYS */;
INSERT INTO `admin_operation_log` VALUES (1,1,'admin','GET','127.0.0.1','{\"s\":\"\\/\\/admin\"}','2022-02-08 19:48:59','2022-02-08 19:48:59'),(2,1,'admin/auth/users','GET','127.0.0.1','{\"s\":\"\\/\\/admin\\/auth\\/users\",\"_pjax\":\"#pjax-container\"}','2022-02-08 19:49:15','2022-02-08 19:49:15'),(3,1,'admin/auth/roles','GET','127.0.0.1','{\"s\":\"\\/\\/admin\\/auth\\/roles\",\"_pjax\":\"#pjax-container\"}','2022-02-08 19:49:20','2022-02-08 19:49:20'),(4,1,'admin/auth/permissions','GET','127.0.0.1','{\"s\":\"\\/\\/admin\\/auth\\/permissions\",\"_pjax\":\"#pjax-container\"}','2022-02-08 19:49:22','2022-02-08 19:49:22'),(5,1,'admin/auth/menu','GET','127.0.0.1','{\"s\":\"\\/\\/admin\\/auth\\/menu\",\"_pjax\":\"#pjax-container\"}','2022-02-08 19:49:24','2022-02-08 19:49:24'),(6,1,'admin/auth/login','GET','127.0.0.1','{\"s\":\"\\/\\/admin\\/auth\\/login\"}','2022-02-08 19:53:48','2022-02-08 19:53:48'),(7,1,'admin','GET','127.0.0.1','{\"s\":\"\\/\\/admin\"}','2022-02-08 19:53:49','2022-02-08 19:53:49');
/*!40000 ALTER TABLE `admin_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permissions`
--

DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_name_unique` (`name`),
  UNIQUE KEY `admin_permissions_slug_unique` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permissions`
--

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'All permission','*','','*',NULL,NULL),(2,'Dashboard','dashboard','GET','/',NULL,NULL),(3,'Login','auth.login','','/auth/login\r\n/auth/logout',NULL,NULL),(4,'User setting','auth.setting','GET,PUT','/auth/setting',NULL,NULL),(5,'Auth management','auth.management','','/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs',NULL,NULL);
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_menu`
--

DROP TABLE IF EXISTS `admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_menu`
--

LOCK TABLES `admin_role_menu` WRITE;
/*!40000 ALTER TABLE `admin_role_menu` DISABLE KEYS */;
INSERT INTO `admin_role_menu` VALUES (1,2,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permissions`
--

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
INSERT INTO `admin_role_permissions` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_users`
--

DROP TABLE IF EXISTS `admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_users_role_id_user_id_index` (`role_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_users`
--

LOCK TABLES `admin_role_users` WRITE;
/*!40000 ALTER TABLE `admin_role_users` DISABLE KEYS */;
INSERT INTO `admin_role_users` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_name_unique` (`name`),
  UNIQUE KEY `admin_roles_slug_unique` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_roles`
--

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Administrator','administrator','2022-02-08 19:48:41','2022-02-08 19:48:41');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_user_permissions`
--

DROP TABLE IF EXISTS `admin_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_user_permissions`
--

LOCK TABLES `admin_user_permissions` WRITE;
/*!40000 ALTER TABLE `admin_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$rvdMh2sxEBFrdbCtZ6ILGO0nzwyMELNFBxbX6C1BkI.G7avUsZlCy','Administrator',NULL,'5xDaBgpleTjNVxhl7XOPQPoLcvoMP8iQbW8O12b1Z3WQo5uoTmn047jQwbw0','2022-02-08 19:48:41','2022-02-08 19:48:41');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2020_01_31_041338_create_students_table',1),(5,'2020_01_31_054213_create_scores_table',1),(6,'2020_02_10_045757_create_provinces_table',1),(7,'2020_02_10_045834_create_schools_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provinces` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `province` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '省份',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=432 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES (11,'北京',NULL,NULL),(12,'天津',NULL,NULL),(13,'河北',NULL,NULL),(14,'山西',NULL,NULL),(15,'内蒙古',NULL,NULL),(21,'辽宁',NULL,NULL),(22,'吉林',NULL,NULL),(23,'黑龙江',NULL,NULL),(31,'上海',NULL,NULL),(32,'江苏',NULL,NULL),(33,'浙江',NULL,NULL),(34,'安徽',NULL,NULL),(35,'福建',NULL,NULL),(36,'江西',NULL,NULL),(37,'山东',NULL,NULL),(41,'河南',NULL,NULL),(42,'湖北',NULL,NULL),(43,'湖南',NULL,NULL),(44,'广东',NULL,NULL),(45,'广西',NULL,NULL),(46,'海南',NULL,NULL),(50,'重庆',NULL,NULL),(51,'四川',NULL,NULL),(52,'贵州',NULL,NULL),(53,'云南',NULL,NULL),(54,'西藏',NULL,NULL),(61,'陕西',NULL,NULL),(62,'甘肃',NULL,NULL),(64,'宁夏',NULL,NULL),(65,'新疆',NULL,NULL),(66,'香港',NULL,NULL),(67,'澳门',NULL,NULL),(68,'台湾',NULL,NULL);
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schools` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cxfs` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'cxfs',
  `dwdm` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '代码',
  `dwmc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '学校名称',
  `kg` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'kg',
  `needlogin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '需要登录',
  `schurl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '学校网址',
  `province_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '所属省份',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `other` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6312 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
INSERT INTO `schools` VALUES (1,'','85305','国家海洋技术中心','','','','12',NULL,NULL,NULL),(2,'','91021','海军勤务学院','','','','12',NULL,NULL,NULL),(3,'chsi','83245','航天科工集团三院8357所','0','1','','12\r\n',NULL,NULL,NULL),(4,'chsi','83246','航天科工集团三院8358所','0','1','','12',NULL,NULL,NULL),(5,'chsi','82804','核工业理化工程研究院','0','1','','12',NULL,NULL,NULL),(6,'','91013','陆军军事交通学院','','','','12',NULL,NULL,NULL),(7,'chsi','10055','南开大学','0','1','','12',NULL,NULL,NULL),(8,'none','10070','天津财经大学','0','','','12',NULL,NULL,NULL),(9,'sch','10792','天津城建大学','0','','www.zhaokao.net','12',NULL,NULL,NULL),(10,'chsi','10056','天津大学','0','1','','12',NULL,NULL,NULL),(11,'','10058','天津工业大学','','','','12',NULL,NULL,NULL),(12,'','86211','天津航海仪器研究所','','','','12',NULL,NULL,NULL),(13,'','10057','天津科技大学','','','','12',NULL,NULL,NULL),(14,'chsi','10060','天津理工大学','0','1','','12',NULL,NULL,NULL),(15,'sch','10073','天津美术学院','0','','http://www.zhaokao.net','12',NULL,NULL,NULL),(16,'sch','10061','天津农学院','0','','www.zhaokao.net','\r\n12',NULL,NULL,NULL),(17,'sch','10069','天津商业大学','0','','www.zhaokao.net','12',NULL,NULL,NULL),(18,'chsi','10065','天津师范大学','0','1','','12',NULL,NULL,NULL),(19,'chsi','10071','天津体育学院','0','1','','12',NULL,NULL,NULL),(20,'','10068','天津外国语大学','','','','12',NULL,NULL,NULL),(21,'','10062','天津医科大学','','','','12',NULL,NULL,NULL),(22,'chsi','10072','天津音乐学院','0','1','','12',NULL,NULL,NULL),(23,'chsi','10066','天津职业技术师范大学','0','1','','12',NULL,NULL,NULL),(24,'sch','10063','天津中医药大学','0','','www.zhaokao.net','12',NULL,NULL,NULL),(25,'','91042','武警后勤学院','','','','12',NULL,NULL,NULL),(26,'','91038','武警指挥学院','','','','12',NULL,NULL,NULL),(27,'','82608','中钢集团天津地质研究院有限公司','','','','12',NULL,NULL,NULL),(28,'chsi','10059','中国民航大学','0','1','','12',NULL,NULL,NULL),(29,'chsi','10009','北方工业大学','0','1','','11',NULL,NULL,NULL),(30,'','82932','北京长城计量测试技术研究所','','','','11',NULL,NULL,NULL),(31,'chsi','11418','北京城市学院','0','1','','11',NULL,NULL,NULL),(32,'chsi','10001','北京大学','0','1','','11',NULL,NULL,NULL),(33,'chsi','10031','北京第二外国语学院','0','0','','11',NULL,NULL,NULL),(34,'chsi','10050','北京电影学院','0','0','','11',NULL,NULL,NULL),(35,'chsi','10018','北京电子科技学院','0','1','','11',NULL,NULL,NULL),(36,'chsi','10012','北京服装学院','0','1','','11',NULL,NULL,NULL),(37,'chsi','10011','北京工商大学','0','1','','11',NULL,NULL,NULL),(38,'chsi','10005','北京工业大学','0','1','','11',NULL,NULL,NULL),(39,'qt','80\r\n401','北京国家会计学院','0','','','11',NULL,NULL,NULL),(40,'chsi','82913','北京航空材料研究院','0','1','','11',NULL,NULL,NULL),(41,'chsi','10006','北京航空航天大学','0','0','','11',NULL,NULL,NULL),(42,'','82902','北京航空精密机械研究所','','','','11',NULL,NULL,NULL),(43,'\r\nchsi','10010','北京化工大学','0','1','','11',NULL,NULL,NULL),(44,'chsi','83501','北京化工研究院','0','0','','11',NULL,NULL,NULL),(45,'chsi','82703','北京机电研究所','0','1','','1\r\n1',NULL,NULL,NULL),(46,'chsi','82702','北京机械工业自动化研究所','0','1','','11',NULL,NULL,NULL),(47,'chsi','10016','北京建筑大学','0','1','','11',NULL,NULL,NULL),(48,'chsi','\r\n10004','北京交通大学','0','0','','11',NULL,NULL,NULL),(49,'chsi','10008','北京科技大学','0','1','','11',NULL,NULL,NULL),(50,'chsi','86402','北京矿冶研究总院','0','1','','11',NULL,NULL,NULL),(51,'chsi','10007','北京理工大学','0','1','','11',NULL,NULL,NULL),(52,'chsi','11417','北京联合大学','0','1','','11',NULL,NULL,NULL),(53,'chsi','10022','北京林业大学','0','0','','11',NULL,NULL,NULL),(54,'chsi','10020','北京农学院','0','1','','11',NULL,NULL,NULL),(55,'chsi','84504','\r\n北京生物制品研究所','0','1','','11',NULL,NULL,NULL),(56,'sch','10027','北京师范大学','0','','http://2021.zs.graduate.bnu.edu.cn/page/sk/cjcx','11',NULL,NULL,NULL),(57,'chsi','10017','北京石油化工学院','0','1','','11',NULL,NULL,NULL),(58,'','87113','北京市创伤骨科研究所','','','','\r\n11',NULL,NULL,NULL),(59,'chsi','87112','北京市结核病胸部肿瘤研究所','0','1','','11',NULL,NULL,NULL),(60,'chsi','87102','北京市科学技术研究院城市安全与环境科学研究所','0','0','','11',NULL,NULL,NULL),(61,'','83702','北京市科学技术研究院资源环境研究所','','','','11',NULL,NULL,NULL),(62,'chsi','87103','北京市生态环境保护科学研究院','0','1','','11',NULL,NULL,NULL),(63,'chsi','87111','北京市市政工程研究院','0','1','','11',NULL,NULL,NULL),(64,'','87110','北京市心肺血管疾病研究所','','','','11',NULL,NULL,NULL),(65,'chsi','10043','北京体育大学','0','0','','11',NULL,NULL,NULL),(66,'\r\nchsi','10030','北京外国语大学','0','1','','11',NULL,NULL,NULL),(67,'chsi','10051','北京舞蹈学院','0','1','','11',NULL,NULL,NULL),(68,'chsi','10037','北京物资学院','0','0','','11',NULL,NULL,NULL),(69,'','83504','北京橡胶工业研究设计院','','','','11',NULL,NULL,NULL),(70,'chsi','10023','北京协和医学院','0','1','','11',NULL,NULL,NULL),(71,'chsi','11232','北京信息科技大学','0','1','','11',NULL,NULL,NULL),(72,'chsi','10015','北京印刷学院','0','1','','11',NULL,NULL,NULL),(73,'\r\nchsi','10013','北京邮电大学','0','1','','11',NULL,NULL,NULL),(74,'chsi','86403','北京有色金属研究总院','0','1','','11',NULL,NULL,NULL),(75,'chsi','10032','北京语言大学','0','1\r\n','','11',NULL,NULL,NULL),(76,'chsi','10026','北京中医药大学','0','1','','11',NULL,NULL,NULL),(77,'chsi','16402','长江商学院','0','1','','11',NULL,NULL,NULL),(78,'','84001','\r\n电信科学技术研究院','','','','11',NULL,NULL,NULL),(79,'chsi','10036','对外经济贸易大学','0','1','','11',NULL,NULL,NULL),(80,'chsi','82601','钢铁研究总院','0','1','','11',NULL,NULL,NULL),(81,'chsi','91001','国防大学','0','1','','11',NULL,NULL,NULL),(82,'chsi','10042','国际关系学院','0','1','','11',NULL,NULL,NULL),(83,'chsi','85304','国家海洋环境预报中心','0','1','','11',NULL,NULL,NULL),(84,'chsi','84601','国家体育总局体育科学研究所','0','1','','11',NULL,NULL,NULL),(85,'chsi','91036','航天工程大学','0','1','','11',NULL,NULL,NULL),(86,'chsi','82806','核工业北京地质研究院','0','1','','11',NULL,NULL,NULL),(87,'','82807','核工业北京化工冶金研究院','','','','11',NULL,NULL,NULL),(88,'','82803','核工业第二研究设计院(中国核电工程有限公司)','','','','11',NULL,NULL,NULL),(89,'chsi','10054','华北电力大学','0','1','','11',NULL,NULL,NULL),(90,'chsi','83001','华北计算机系统工程研究所','0','1','','11',NULL,NULL,NULL),(91,'chsi','82701','机械科学研究总院','0','1','','11',NULL,NULL,NULL),(92,'chsi','83902','交通运输部公路科学研究所','0','1','','11',NULL,NULL,NULL),(93,'chsi','91102','解放军医学院','0','1','','11',NULL,NULL,NULL),(94,'chsi','91101','军事科学院','0','1\r\n','','11',NULL,NULL,NULL),(95,'chsi','91023','空军指挥学院','0','1','','11',NULL,NULL,NULL),(96,'chsi','91011','陆军防化学院','0','1','','11',NULL,NULL,NULL),(97,'chsi','91008','\r\n陆军航空兵学院','0','1','','11',NULL,NULL,NULL),(98,'chsi','91006','陆军装甲兵学院','0','0','','11',NULL,NULL,NULL),(99,'chsi','83301','煤炭科学研究总院','0','1','','11',NULL,NULL,NULL),(100,'chsi','10003','清华大学','0','0','','11',NULL,NULL,NULL),(101,'ch\r\nsi','82001','商务部国际贸易经济合作研究院','0','1','','11',NULL,NULL,NULL),(102,'chsi','87120','首都儿科研究所','0','1','','11',NULL,NULL,NULL),(103,'chsi','10038','首都经济贸易大学','0','1','','1\r\n1',NULL,NULL,NULL),(104,'chsi','10028','首都师范大学','0','1','','11',NULL,NULL,NULL),(105,'chsi','10029','首都体育学院','0','1','','11',NULL,NULL,NULL),(106,'chsi','10025','首都医科大学','0','1','','11',NULL,NULL,NULL),(107,'chsi','10040','外交学院','0','1','','11',NULL,NULL,NULL),(108,'chsi','84512','卫生部北京老年医学研究所','0','1','','11',NULL,NULL,NULL),(109,'chsi','82605','冶金自动化研究设计院','0','1','','11',NULL,NULL,NULL),(110,'chsi','85407','应急管理部国家自然灾害防治研究院','0','1','','11',NULL,NULL,NULL),(111,'chsi','89611','中共北京市委党校','0','1','','11',NULL,NULL,NULL),(112,'chsi','80000','中共中央党校(国家行政学院)','0','1','','11',NULL,NULL,NULL),(113,'chsi','83107','中国北方车辆研究所','0','1','','11',NULL,NULL,NULL),(114,'chsi','81601','中国财政科学研究院','0','1','','11',NULL,NULL,NULL),(115,'chsi','86001','中国测绘科学研究院','0','0','','11',NULL,NULL,NULL),(116,'chs\r\ni','82402','中国城市规划设计研究院','0','1','','11',NULL,NULL,NULL),(117,'','10033','中国传媒大学','','','','11',NULL,NULL,NULL),(118,'chsi','85401','中国地震局地球物理研究所','0','1','','11\r\n',NULL,NULL,NULL),(119,'chsi','85405','中国地震局地震预测研究所','0','1','','11',NULL,NULL,NULL),(120,'chsi','85402','中国地震局地质研究所','0','1','','11\r\n',NULL,NULL,NULL),(121,'chsi','11415','中国地质大学(北京)','0','1','','11',NULL,NULL,NULL),(122,'chsi','82501','中国地质科学院','0','0','','11',NULL,NULL,NULL),(123,'chsi','82302\r\n','中国电力科学研究院','0','1','','11',NULL,NULL,NULL),(124,'chsi','84202','中国电影艺术研究中心','0','1','','11',NULL,NULL,NULL),(125,'chsi','83000','中国电子科技集团公司电子科学研究院','0','1','','11',NULL,NULL,NULL),(126,'chsi','82817','中国工程物理研究院','0','1','','11',NULL,NULL,NULL),(127,'chsi','82\r\n920','中国航空规划设计研究总院有限公司','0','0','','11',NULL,NULL,NULL),(128,'','82901','中国航空研究院','','','','11',NULL,NULL,NULL),(129,'\r\nchsi','82914','中国航空制造技术研究院','0','1','','11',NULL,NULL,NULL),(130,'chsi','83221','中国航天科工集团第二研究院','0','1','','11',NULL,NULL,NULL),(131,'chsi','83241','中国航天科工集团第三研究院','0','1','','11',NULL,NULL,NULL),(132,'','83277','中国航天科技集团公司第十一研究院','','','','11',NULL,NULL,NULL),(133,'chsi','83232','中国航天系统科学与工程研究院','0','1','','11',NULL,NULL,NULL),(134,'chsi','82405','中国环境科学研究院','0','0','','11',NULL,NULL,NULL),(135,'chsi','84501','中国疾病预防控制中心','0','1','','11',NULL,NULL,NULL),(136,'chsi','85801','中国计量科学研究院','0','1','','11',NULL,NULL,NULL),(137,'chsi','84901','中国建筑材料科学研究总院','0','1','','11',NULL,NULL,NULL),(138,'chsi','82401','中国建筑科学研究院','0','1','','11',NULL,NULL,NULL),(139,'chsi','82403','中国建筑设计研究院','0','1','','11',NULL,NULL,NULL),(140,'','86201','中国舰船研究院','','','','11',NULL,NULL,NULL),(141,'chsi','80901','中国科学技术信息研究所','0','0\r\n','','11',NULL,NULL,NULL),(142,'sch','14430','中国科学院大学','0','','https://admission.ucas.ac.cn/','11',NULL,NULL,NULL),(143,'chsi','83266','中国空间技术研究院(航天五院)','0','1','','11',NULL,NULL,NULL),(144,'chsi','11413','中国矿业大学(北京)','0','0','','11',NULL,NULL,NULL),(145,'chsi','12453','中国劳动关系学院','0','0','\r\n','11',NULL,NULL,NULL),(146,'chsi','82201','中国林业科学研究院','0','1','','11',NULL,NULL,NULL),(147,'chsi','10019','中国农业大学','0','\r\n0','','11',NULL,NULL,NULL),(148,'chsi','82715','中国农业机械化科学研究院','0','1','','11',NULL,NULL,NULL),(149,'chsi','82101','中国农业科学院','0','1','','11\r\n',NULL,NULL,NULL),(150,'chsi','85101','中国气象科学研究院','0','0','','11',NULL,NULL,NULL),(151,'chsi','11625','中国青年政治学院','0','1','','11',NULL,NULL,NULL),(152,'chsi','100\r\n02','中国人民大学','0','1','','11',NULL,NULL,NULL),(153,'chsi','10041','中国人民公安大学','0','1','','11',NULL,NULL,NULL),(154,'chsi','14596','中国社会科学院大学','0','1','','11',NULL,NULL,NULL),(155,'chsi','11414','中国石油大学(北京)','0','1','','11',NULL,NULL,NULL),(156,'chsi','86301','中国石油化工股份有限公司石油化工科学研究院','0','0','','11',NULL,NULL,NULL),(157,'chsi','83401','中国石油勘探开发研究院','0','1','','11',NULL,NULL,NULL),(158,'chsi','83705','中国食品发酵工业研究院','0','1','','11',NULL,NULL,NULL),(159,'chsi','84503','中国食品药品检定研究院','0','0','','11',NULL,NULL,NULL),(160,'chsi','82110','中国兽医药品监察所','0','1','','11',NULL,NULL,NULL),(161,'chsi','82301','中国水利水电科学研究院','0','1','','11',NULL,NULL,NULL),(162,'','83801','中\r\n国铁道科学研究院','','','','11',NULL,NULL,NULL),(163,'chsi','10049','中国戏曲学院','0','0','','11',NULL,NULL,NULL),(164,'ch\r\nsi','84201','中国艺术研究院','0','1','','11',NULL,NULL,NULL),(165,'chsi','10046','中国音乐学院','0','1','','11',NULL,NULL,NULL),(166,'chsi','82801','中国原子能科学研究院','0','1','','11',NULL,NULL,NULL),(167,'chsi','83201','中国运载火箭技术研究院','0','0','','11',NULL,NULL,NULL),(168,'chsi','10053','中国政法大学','0','1','','11',NULL,NULL,NULL),(169,'chsi','\r\n83706','中国制浆造纸研究院有限公司','0','1','','11',NULL,NULL,NULL),(170,'chsi','84502','中国中医科学院','0','1','','11',NULL,NULL,NULL),(171,'chsi','1114\r\n9','中华女子学院','0','0','','11',NULL,NULL,NULL),(172,'chsi','84508','中日友好临床医学研究所','0','1','','11',NULL,NULL,NULL),(173,'chsi','10034','中央财经大学','0','0','','11',NULL,NULL,NULL),(174,'chsi','10047','中央美术学院','0','1','','11',NULL,NULL,NULL),(175,'chsi','10052','中央民族大学','0\r\n','1','','11',NULL,NULL,NULL),(176,'chsi','10048','中央戏剧学院','0','0','','11',NULL,NULL,NULL),(177,'chsi','10045','中央音乐学院','0','1','','11',NULL,NULL,NULL),(178,'chsi','8260\r\n2','中冶建筑研究总院有限公司','0','1','','11',NULL,NULL,NULL),(179,'chsi','11629','北华航天工业学院','0','1','','13',NULL,NULL,NULL),(180,'chsi','10093','承德医学院','0','1','','13',NULL,NULL,NULL),(181,'chsi','11775','防灾科技学院','0','1','','13\r\n',NULL,NULL,NULL),(182,'','86221','邯郸净化设备研究所','','','','13',NULL,NULL,NULL),(183,'chsi','10092','河北北方学院','0','1','','13',NULL,NULL,NULL),(184,'chsi','12784','河北传媒学院','0','1','','13',NULL,NULL,NULL),(185,'chsi','10075','河北大学','0','1','','13',NULL,NULL,NULL),(186,'\r\nchsi','10077','河北地质大学','0','1','','13',NULL,NULL,NULL),(187,'chsi','10076','河北工程大学','0','1','','13',NULL,NULL,NULL),(188,'chsi','10080','河北工业大学','0','1','','13',NULL,NULL,NULL),(189,'chsi','10084','河北建筑工程学院','0','1','','13',NULL,NULL,NULL),(190,'chsi','11420','河北金融学院','0','1','','13',NULL,NULL,NULL),(191,'chsi','1\r\n1832','河北经贸大学','0','1','','13',NULL,NULL,NULL),(192,'chsi','10082','河北科技大学','0','1','','13',NULL,NULL,NULL),(193,'chsi','10798','河北科技师范学院','0','1','','13',NULL,NULL,NULL),(194,'chsi','10086','河北农业大学','0','1','','13',NULL,NULL,NULL),(195,'\r\nchsi','10094','河北师范大学','0','1','','13',NULL,NULL,NULL),(196,'chsi','10089','河北医科大学','0','1','','13',NULL,NULL,NULL),(197,'chsi','14432','河北中医学院','0','1','','13',NULL,NULL,NULL),(198,'chsi','10079','华北电力大学(保定)','0','1','','13',NULL,NULL,NULL),(199,'chsi','11104','华北科技学院','0','1','','13',NULL,NULL,NULL),(200,'chsi','10081','华北理工大学','0','1','','13',NULL,NULL,NULL),(201,'chsi','10107','石家庄铁道大学','0','1','','13',NULL,NULL,NULL),(202,'','10216','燕山大学','','','','13',NULL,NULL,NULL),(203,'sch','11105','中国人民警察大学','0','','http://47.105.75.197:8156/ASPX/Student/StuLogin.aspx','13',NULL,NULL,NULL),(204,'chsi','11903','中央司法警官学院','0','1','','13',NULL,NULL,NULL),(205,'','83106','北方自动控制技术研究所','','','','14',NULL,NULL,NULL),(206,'','10117','长治医学院','','','','14',NULL,NULL,NULL),(207,'chsi','10125','山西财经大学','0','1','','14',NULL,NULL,NULL),(208,'','10120','山西大同大学','','','','14',NULL,NULL,NULL),(209,'chsi','10108','山西大学','0','1','','14',NULL,NULL,NULL),(210,'','10113','山西农业大学','','','','14',NULL,NULL,NULL),(211,'','87401','山西省中医药研究院','','','','14',NULL,NULL,NULL),(212,'','10118','山西师范大学','','','','14',NULL,NULL,NULL),(213,'','\r\n10114','山西医科大学','','','','14',NULL,NULL,NULL),(214,'','10809','山西中医药大学','','','','14',NULL,NULL,NULL),(215,'','10109','太原科技大学','','','','14',NULL,NULL,NULL),(216,'chsi','10112','太原理工大学','0','1','','14',NULL,NULL,NULL),(217,'','10119','太原师范学院','','','','14',NULL,NULL,NULL),(218,'sch','1\r\n0110','中北大学','0','','http://yz.chsi.com.cn/apply/cjcx/','14',NULL,NULL,NULL),(219,'','82808','中国辐射防护研究院','','','','14',NULL,NULL,NULL),(220,'','83704','中国日用化学工业研究院','','','','14',NULL,NULL,NULL),(221,'chsi','10138','赤峰学院','0','1','','15',NULL,NULL,NULL),(222,'chsi','10139','内蒙古财经大学','0','1','','15',NULL,NULL,NULL),(223,'chsi','10126','内蒙古大学','0','1','','15',NULL,NULL,NULL),(224,'chsi','10128','内蒙古工业大学','0','1','','15',NULL,NULL,NULL),(225,'chsi','10127','内蒙古科技大学','0','1','','15',NULL,NULL,NULL),(226,'chsi','10136','内蒙古民族大学','0','0','','15',NULL,NULL,NULL),(227,'chsi','10129','内蒙古农业大学','0','1','','15',NULL,NULL,NULL),(228,'chsi','10135','内蒙古师范大学','0','1','','15',NULL,NULL,NULL),(229,'chsi','10132','内蒙古医科大学','0','1','','15',NULL,NULL,NULL),(230,'chsi','14531','内蒙古艺术学院','0','0','','15',NULL,NULL,NULL),(231,'chsi','83102','内蒙金属材料研究所(52所)','0','1','','15',NULL,NULL,NULL),(232,'sch','10169','鞍山师范学院','0','','http://47.104\r\n.177.254:8310/ASPX/Student/StuLogin.aspx','21',NULL,NULL,NULL),(233,'chsi','10167','渤海大学','0','1','','21',NULL,NULL,NULL),(234,'chsi','86220','\r\n大连测控技术研究所','0','1','','21',NULL,NULL,NULL),(235,'chsi','11258','大连大学','0','1','','21',NULL,NULL,NULL),(236,'\r\nchsi','10152','大连工业大学','0','1','','21',NULL,NULL,NULL),(237,'chsi','10151','大连海事大学','0','1','','21',NULL,NULL,NULL),(238,'chsi','10158','大连海洋大学','0','1','','21',NULL,NULL,NULL),(239,'chsi','10150','大连交通大学','0','1','','21',NULL,NULL,NULL),(240,'chsi','10141','大连理工大学','0','1','','21',NULL,NULL,NULL),(241,'chsi','12026','大连民族大学','0','1','','21',NULL,NULL,NULL),(242,'chsi','10172','大连外国语大学','0','1','','21',NULL,NULL,NULL),(243,'sch','10161','大连医科大学','0','','http://210.\r\n47.245.63/ksxt/login.aspx','21',NULL,NULL,NULL),(244,'sch','10173','东北财经大学','0','','http://graduate.dufe.edu.cn/','21',NULL,NULL,NULL),(245,'chsi','10145','东北大学','0','1','','21',NULL,NULL,NULL),(246,'chsi','91017','海军大连舰艇学院','0','1','','21',NULL,NULL,NULL),(247,'chsi','10160','锦州医科大学','0','1','','21',NULL,NULL,NULL),(248,'chsi','10140','辽宁大学','0','1','','21',NULL,NULL,NULL),(249,'sch','10147','辽宁工程技术大学','0','','http://47.1\r\n05.75.197:5666/ASPX/Student/StuLogin.aspx','21',NULL,NULL,NULL),(250,'chsi','10154','辽宁工业大学','0','1','','21',NULL,NULL,NULL),(251,'chsi','1014\r\n6','辽宁科技大学','0','0','','21',NULL,NULL,NULL),(252,'chsi','10165','辽宁师范大学','0','1','','21',NULL,NULL,NULL),(253,'chsi','10148','辽宁石油化工大学\r\n','0','1','','21',NULL,NULL,NULL),(254,'chsi','10162','辽宁中医药大学','0','1','','21',NULL,NULL,NULL),(255,'sch','10178','鲁迅美术学院','0','','http://210.30.2\r\n32.137/cscj.aspx','21',NULL,NULL,NULL),(256,'chsi','11035','沈阳大学','0','1','','21',NULL,NULL,NULL),(257,'chsi','11632','沈阳工程学院','\r\n0','1','','21',NULL,NULL,NULL),(258,'sch','10142','沈阳工业大学','0','','http://47.104.177.254:8799/ASPX/Student/StuLogin.aspx','21',NULL,NULL,NULL),(259,'sch','10\r\n143','沈阳航空航天大学','0','','http://47.105.75.197:8843/ASPX/Student/StuLogin.aspx','21',NULL,NULL,NULL),(260,'chsi','10149','沈阳化工大学','0','0','','21',NULL,NULL,NULL),(261,'chsi','83503','沈阳化工研究院','0','1','','21',NULL,NULL,NULL),(262,'chsi','10153','沈阳建筑大学','0','1','','21',NULL,NULL,NULL),(263,'chsi','10144','沈阳理工大学','0','1','','21',NULL,NULL,NULL),(264,'chsi','10157','沈阳农业大学','0','1','','21',NULL,NULL,NULL),(265,'chsi','10166','沈阳师范大学','0','1','','21',NULL,NULL,NULL),(266,'sch','10176','沈阳体育学院','0','','http://yjsxt.syty.edu.cn/gsapp/sys/yjsbmxsd/entrance.\r\ndo','21',NULL,NULL,NULL),(267,'chsi','10163','沈阳药科大学','0','1','','21',NULL,NULL,NULL),(268,'chsi','10164','沈阳医学院','0','1','','21',NULL,NULL,NULL),(269,'sch','10177','沈阳音乐学院','0','','http://47.105.75.197:6653/ASPX/Student/StuLogin.aspx','21',NULL,NULL,NULL),(270,'chsi','82705','沈阳铸造研究所','0','1','','21',NULL,NULL,NULL),(271,'chsi','89621','中共辽宁省委党校','0','1','','21',NULL,NULL,NULL),(272,'chsi','82903','中国航空研究院601所','0','1','','21',NULL,NULL,NULL),(273,'chsi','82905','中国航空研究院606研究所','0','1','','21',NULL,NULL,NULL),(274,'chsi','82929','中国航空研究院626所','0','1','\r\n','21',NULL,NULL,NULL),(275,'chsi','10175','中国刑事警察学院','0','1','','21',NULL,NULL,NULL),(276,'chsi','10159','中国医科大学','0','0','','21',NULL,NULL,NULL),(277,'chsi','10201','北华大学','0','1','','22',NULL,NULL,NULL),(278,'chsi','11726','长春大学','0','1','','22',NULL,NULL,NULL),(279,'chsi','11437','长春工程学院','0','1','','22',NULL,NULL,NULL),(280,'chsi','101\r\n90','长春工业大学','0','0','','22',NULL,NULL,NULL),(281,'chsi','10186','长春理工大学','0','1','','22',NULL,NULL,NULL),(282,'chsi','84509','长春生物制品研究所','0','1','','22',NULL,NULL,NULL),(283,'chsi','10205','长春师范大学','0','1','','22',NULL,NULL,NULL),(284,'chsi','10199','长春中医药大学','0','1','','22',NULL,NULL,NULL),(285,'chsi','10188','东北电力大学','0','1','','22',NULL,NULL,NULL),(286,'chsi','10200','东北师范大学','0','1','','22',NULL,NULL,NULL),(287,'chsi','10207','吉林财经大学','0','1','','22',NULL,NULL,NULL),(288,'chsi','10183','吉林大学','0','1','','22',NULL,NULL,NULL),(289,'chsi','10192','吉林化工学院','0','1','','22',NULL,NULL,NULL),(290,'chsi','10191','吉林建筑大学','0','1','','22',NULL,NULL,NULL),(291,'chsi','10193','吉林农业大学','0','1','','22',NULL,NULL,NULL),(292,'chsi','10203','吉林师范大学','0','1','','22',NULL,NULL,NULL),(293,'chsi','10208','吉林体育学院','0','1','','22',NULL,NULL,NULL),(294,'chsi','10964','吉林外国语大学','0','1','','22',NULL,NULL,NULL),(295,'chsi','10209','吉林艺术学院','0','1','','22',NULL,NULL,NULL),(296,'chsi','91025','空军航空大学','0','1','','22',NULL,NULL,NULL),(297,'chsi','10184','延边大学','0','1','','22',NULL,NULL,NULL),(298,'chsi','89622','中共吉林 省委党校(吉林省行政学院)','0','1','','22',NULL,NULL,NULL),(299,'','84002','电信科学技术第一研究所(上海)','','','','31',NULL,NULL,NULL),(300,'chsi','10255','东华大学','0','1','','31',NULL,NULL,NULL),(301,'','10246','复旦大学','','','','31',NULL,NULL,NULL),(302,'chsi','91020','海军军医大学','0','0','','31',NULL,NULL,NULL),(303,'chsi','10251','华东理工大学','0','1','','31',NULL,NULL,NULL),(304,'chsi\r\n','10269','华东师范大学','0','1','','31',NULL,NULL,NULL),(305,'chsi','10276','华东政法大学','0','1','','31',NULL,NULL,NULL),(306,'chsi','82707','上海材料研究所','0','1','','31',NULL,NULL,NULL),(307,'','10272','上海财经大学','','','','31',NULL,NULL,NULL),(308,'','86219','上海船舶电子设备研究所','','','','31',NULL,NULL,NULL),(309,'chsi','86207','上海船舶设备研究所','0','1','','31',NULL,NULL,NULL),(310,'','83901','上海船舶运输科学研究所','','','','31',NULL,NULL,NULL),(311,'chsi','86208','上海船用柴油机研究所','0','0','','31',NULL,NULL,NULL),(312,'','10280','上海大学','','','','31',NULL,NULL,NULL),(313,'chsi','12044','上海第二工业大学','0','1','','31',NULL,NULL,NULL),(314,'chsi','11458','上海电机学院','0','0','','31',NULL,NULL,NULL),(315,'','10256','上海电力大学','','','','31',NULL,NULL,NULL),(316,'chsi','10273','上海对外经贸大学','0','1','','31',NULL,NULL,NULL),(317,'chsi','82717','上海发电设备成套设计研究院','0','0','','31',NULL,NULL,NULL),(318,'','10856','上海工程技术大学','','','','31',NULL,NULL,NULL),(319,'chsi','87902','上海国际问题研究院','0','0','','31',NULL,NULL,NULL),(320,'','80402','上海国家会计学院','','','','31',NULL,NULL,NULL),(321,'chsi','10274','上海海关学院','0','1','','31',NULL,NULL,NULL),(322,'chsi','10254','上海海事大学','0','1','','31',NULL,NULL,NULL),(323,'sch','10264','上海海洋大学','0','','http://yz.shou.edu.cn/xscx/','31',NULL,NULL,NULL),(324,'chsi','83285','上海航天技术研究院','0','0','','31',NULL,NULL,NULL),(325,'chsi','835\r\n02','上海化工研究院','0','1','','31',NULL,NULL,NULL),(326,'','10248','上海交通大学','','','','31',NULL,NULL,NULL),(327,'c\r\nhsi','14423','上海科技大学','0','1','','31',NULL,NULL,NULL),(328,'chsi','10252','上海理工大学','0','1','','31',NULL,NULL,NULL),(329,'','11047','上海立信会计金融学院','','','','31',NULL,NULL,NULL),(330,'chsi','87903','上海社会科学院','0','1','','31',NULL,NULL,NULL),(331,'chsi','84505','上海生物制品研究所','0','1','','31',NULL,NULL,NULL),(332,'chsi','10270','上海师范大学','0','1','','31',NULL,NULL,NULL),(333,'','10277','上海体育学院','','','','31',NULL,NULL,NULL),(334,'','10271','上海外国语大学','','','','31',NULL,NULL,NULL),(335,'chsi','10279','上海戏剧学院','0','1','','31',NULL,NULL,NULL),(336,'chsi','10278','上海音乐学院','0','1','','31',NULL,NULL,NULL),(337,'chsi','10259','上海应用技术大学','0','1','','31',NULL,NULL,NULL),(338,'chsi','11835','上海政法学院','0','1','','31',NULL,NULL,NULL),(339,'chsi','10268','上海中医药大学','0','1','','31',NULL,NULL,NULL),(340,'chsi','10247','同济大学','0','1','','31',NULL,NULL,NULL),(341,'','89631','中共上海市委党校','','','','31',NULL,NULL,NULL),(342,'chsi','86206','中国船舶及海洋工程设计研究院','0','1','','31',NULL,NULL,NULL),(343,'chsi','82937','中国航空研究院640所','0','1','','31',NULL,NULL,NULL),(344,'','85901','中国医药工业研究总院','','','','31',NULL,NULL,NULL),(345,'','10292','常州大学','','','','32',NULL,NULL,NULL),(346,'','10286','东南大学','','','','32',NULL,NULL,NULL),(347,'','82303','国网电力科学研究院','','','','32',NULL,NULL,NULL),(348,'','91015','海军指 \r\n挥学院','','','','32',NULL,NULL,NULL),(349,'','10294','河海大学','','','','32',NULL,NULL,NULL),(350,'','11049','淮阴工学院','','','','32',NULL,NULL,NULL),(351,'','10295','江南大学','','','','32',NULL,NULL,NULL),(352,'sch','10299','江苏大学','0','','http://yz.ujs.edu.cn','32',NULL,NULL,NULL),(353,'chsi','11641','江苏 海洋大学','0','0','','32',NULL,NULL,NULL),(354,'','10289','江苏科技大学','','','','32',NULL,NULL,NULL),(355,'','11463','江苏理工学院','','','','32',NULL,NULL,NULL),(356,'','88002','江苏省血吸虫病防治研究所','','','','32',NULL,NULL,NULL),(357,'sch','88001','江苏省中国科学院植物研究所','0','','https://ww\r\nw.jseea.cn/graduateenrollment.html','32',NULL,NULL,NULL),(358,'','10320','江苏师范大学','','','','32',NULL,NULL,NULL),(359,'','86210','江苏自动化研究所','','','','32',NULL,NULL,NULL),(360,'','91031','空军勤务学院','','','','32',NULL,NULL,NULL),(361,'','91004','陆军工程大学','','','','32',NULL,NULL,NULL),(362,'','91003','陆军指挥学院','','','','32',NULL,NULL,NULL),(363,'','10327','南京财经大学','','','','32',NULL,NULL,NULL),(364,'','10284','南京大学','','','','32',NULL,NULL,NULL),(365,'','11276','南京工程学院','','','','32',NULL,NULL,NULL),(366,'','10291','南京工业大学','','','','32',NULL,NULL,NULL),(367,'','102\r\n87','南京航空航天大学','','','','32',NULL,NULL,NULL),(368,'','10288','南京理工大学','','','','32',NULL,NULL,NULL),(369,'','10298','南京林业大学','','','','32',NULL,NULL,NULL),(370,'chsi','10307','南京农业大学','0','0','','32',NULL,NULL,NULL),(371,'','11287','南京审计大学','','','','32',NULL,NULL,NULL),(372,'','10\r\n319','南京师范大学','','','','32',NULL,NULL,NULL),(373,'','82306','南京水利科学研究院','','','','32',NULL,NULL,NULL),(374,'','10330','南京体育学院','','','','32',NULL,NULL,NULL),(375,'chsi','10300','南京信息工程大学','0','0','','32',NULL,NULL,NULL),(376,'chsi','10312','南京医科大学','0','1','','32',NULL,NULL,NULL),(377,'','10331','南京艺术学院','','','','32',NULL,NULL,NULL),(378,'','10293','南京邮电大学','','','','32',NULL,NULL,NULL),(379,'','10315','南京中医药大学','','','','32',NULL,NULL,NULL),(380,'','10304','南通大学','','','','32',NULL,NULL,NULL),(381,'','10285','苏州大学','','','','32',NULL,NULL,NULL),(382,'','1033\r\n2','苏州科技大学','','','','32',NULL,NULL,NULL),(383,'','10313','徐州医科大学','','','','32',NULL,NULL,NULL),(384,'','10305','盐城工学院','','','','32',NULL,NULL,NULL),(385,'','11117','扬州大学','','','','32',NULL,NULL,NULL),(386,'','89632','中共江苏省委党校','','','','32',NULL,NULL,NULL),(387,'','86205','中国船 舶科学研究中心','','','','32',NULL,NULL,NULL),(388,'','82927','中国航空研究院609研究所','','','','32',NULL,NULL,NULL),(389,'sch','10290','中国矿业大学','0','','http://yjsxt.cumt.edu.cn/open/RecruitTkss/signin.aspx','32',NULL,NULL,NULL),(390,'','10316','中国药科大学','','','','\r\n32',NULL,NULL,NULL),(391,'chsi','10336','杭州电子科技大学','0','1','','33',NULL,NULL,NULL),(392,'chsi','10346','杭州师范大学','0','0','','33',NULL,NULL,NULL),(393,'chsi','86204','杭州应用声学研究所','0','1','','33',NULL,NULL,NULL),(394,'chsi','10347','湖州师范学院','0','1','','33',NULL,NULL,NULL),(395,'chsi','11646','宁波大学','0','1','','33',NULL,NULL,NULL),(396,'chsi','10349','绍兴文理学院','0','1','','33',NULL,NULL,NULL),(397,'chsi','10351','温州大学','0','1','','33',NULL,NULL,NULL),(398,'chsi','10343','温州医科大学','0','1','','33',NULL,NULL,NULL),(399,'chsi','11482','浙江财经大学','0','0','','33',NULL,NULL,NULL),(400,'chsi','11647','浙江传媒学院','0','1','','33',NULL,NULL,NULL),(401,'chsi','10335','浙江大学','0','1','','33',NULL,NULL,NULL),(402,'chsi','10353','浙江工商大学','0','1','','33',NULL,NULL,NULL),(403,'chsi','10337\r\n','浙江工业大学','0','1','','33',NULL,NULL,NULL),(404,'chsi','10340','浙江海洋大学','0','0','','33',NULL,NULL,NULL),(405,'chsi','11057','浙江科技学院','0','1','','33',NULL,NULL,NULL),(406,'chsi','10338','浙江理工大学','0','0','','33',NULL,NULL,NULL),(407,'chsi','10341','浙江农林大学','0\r\n','1','','33',NULL,NULL,NULL),(408,'chsi','88101','浙江省医学科学院','0','1','','33',NULL,NULL,NULL),(409,'chsi','10345','浙江师范大学','0','1','','33',NULL,NULL,NULL),(410,'chsi','10876','浙江万里学院','0','0','','33',NULL,NULL,NULL),(411,'chsi','14535','浙江音乐学院','0','1','','33',NULL,NULL,NULL),(412,'chsi','10344','浙江中医药大学','0','1','','33',NULL,NULL,NULL),(413,'chsi','89633','中共浙江省委党校','0','1','','33',NULL,NULL,NULL),(414,'chsi','10356','中国计量大学','0','1','','33',NULL,NULL,NULL),(415,'chsi','10355','中国美术学院','0','1','','33',NULL,NULL,NULL),(416,'chsi','85302','自然资源部第二海洋研究 所','0','1','','33',NULL,NULL,NULL),(417,'chsi','10378','安徽财经大学','0','1','','34',NULL,NULL,NULL),(418,'chsi','10357','安徽大学','0','1','','34',NULL,NULL,NULL),(419,'','10363','安徽工程大学','','','','34',NULL,NULL,NULL),(420,'chsi','10360\r\n','安徽工业大学','0','1','','34',NULL,NULL,NULL),(421,'chsi','10878','安徽建筑大学','0','1','','34',NULL,NULL,NULL),(422,'chsi','10879','安徽科技学院','0','1','','34',NULL,NULL,NULL),(423,'chsi','10361','安徽理工大学','0','1','','34',NULL,NULL,NULL),(424,'chsi','10364','安徽农业大学','0\r\n','1','','34',NULL,NULL,NULL),(425,'','10370','安徽师范大学','','','','34',NULL,NULL,NULL),(426,'','10366','安徽医科大学','','','','34',NULL,NULL,NULL),(427,'chsi','10369','安徽中医药大学','0','0','','34',NULL,NULL,NULL),(428,'chsi','10372','安庆师范大学','0','1','','34',NULL,NULL,NULL),(429,'chsi','10367','蚌埠医学院','0','1','','34',NULL,NULL,NULL),(430,'chsi','10371','阜阳师范大学','0','0','','34',NULL,NULL,NULL),(431,'chsi','10359','合肥工业大学','0','1','','34',NULL,NULL,NULL),(432,'chsi','14098','合肥师范学院','0','1','','34',NULL,NULL,NULL),(433,'chsi','11059','合肥学院','0','1','','34',NULL,NULL,NULL),(434,'chsi','10373','\r\n淮北师范大学','0','1','','34',NULL,NULL,NULL),(435,'chsi','91007','陆军炮兵防空兵学院','0','1','','34',NULL,NULL,NULL),(436,'chsi','10368','皖南医学院','0','0','','34',NULL,NULL,NULL),(437,'chsi','82604','中钢集团马鞍山矿山研究院','0','1','','34',NULL,NULL,NULL),(438,'','10358','中国科学技术 大学','','','','34',NULL,NULL,NULL),(439,'chsi','10388','福建工程学院','0','1','','35',NULL,NULL,NULL),(440,'chsi','10389','福建农林大学','0','1','','35',NULL,NULL,NULL),(441,'chsi','10394','福建师范大学','0','1','','35',NULL,NULL,NULL),(442,'chsi','10392','福建医科大学','0','1','','35',NULL,NULL,NULL),(443,'chsi','10393','福建中医药大学','0','1','','35',NULL,NULL,NULL),(444,'chsi','10386','福州大学','0','1','','35',NULL,NULL,NULL),(445,'chsi','10385','华侨大学','0','1','','35',NULL,NULL,NULL),(446,'chsi','10390','集美大学','0\r\n','1','','35',NULL,NULL,NULL),(447,'chsi','10395','闽江学院','0','1','','35',NULL,NULL,NULL),(448,'chsi','10402','闽南师范大学','0','1','','35',NULL,NULL,NULL),(449,'chsi','10399','泉州师范学院','0','1','','35',NULL,NULL,NULL),(450,'chsi','10384','厦门大学','0','1','','35',NULL,NULL,NULL),(451,'chsi','80403','厦门国家会计 \r\n学院','0','1','','35',NULL,NULL,NULL),(452,'chsi','11062','厦门理工学院','0','1','','35',NULL,NULL,NULL),(453,'chsi','85303','自然资源部第三海洋研究所','0','1','','35',NULL,NULL,NULL),(454,'chsi','10405','东华理工大学','0','0','','36',NULL,NULL,NULL),(455,'chsi','10418','赣南师范大学','0','0','','36',NULL,NULL,NULL),(456,'chsi','10413','赣南医学院','0','1','','36',NULL,NULL,NULL),(457,'chsi','10404','华东交通大学','0','1','','36',NULL,NULL,NULL),(458,'chsi','10421','江西财经大学','0','1','','36',NULL,NULL,NULL),(459,'chsi','11318','江西科技师范大学','0','1','','36',NULL,NULL,NULL),(460,'chsi','10407','江西理工大学','0','1','','36',NULL,NULL,NULL),(461,'chsi','10410','江西农业大学','0','1','','36',NULL,NULL,NULL),(462,'chsi','10414','江西师范大学','0','1','','36',NULL,NULL,NULL),(463,'chsi','10412','江西中医药大学','0','1','','36',NULL,NULL,NULL),(464,'chsi','10419','井冈山大学','0','0','','36',NULL,NULL,NULL),(465,'chsi','10408','景德镇陶瓷大学','0','1','','36',NULL,NULL,NULL),(466,'chsi','91005','陆军步兵学院','0','0','','36',NULL,NULL,NULL),(467,'chsi','10403','南昌大学','0','1','','36',NULL,NULL,NULL),(468,'chsi','11319','南昌工程学院','0','1','','36',NULL,NULL,NULL),(469,'chsi','10406','南昌航空大学','0','1','','36',NULL,NULL,NULL),(470,'chsi','10417','宜春学院','0','1','','36',NULL,NULL,NULL),(471,'chsi','82938','中国航空研究院602研究所','0','1','','36',NULL,NULL,NULL),(472,'chsi','10440','滨州医学院','0','1','','37',NULL,NULL,NULL),(473,'qt','91019','海军航空大学','0','','','37',NULL,NULL,NULL),(474,'','91018','海军潜艇学院','','','','37',NULL,NULL,NULL),(475,'chsi','10427','济南大学','0','1','','37',NULL,NULL,NULL),(476,'chsi','10443','济宁医学院','0','0','','37',NULL,NULL,NULL),(477,'chsi','10447','聊城大学','0','1','','37',NULL,NULL,NULL),(478,'chsi','10452','临沂大学','0','1','','37',NULL,NULL,NULL),(479,'chsi','10451','鲁东大学','0','1','','37',NULL,NULL,NULL),(480,'chsi','104\r\n31','齐鲁工业大学','0','0','','37',NULL,NULL,NULL),(481,'chsi','11065','青岛大学','0','1','','37',NULL,NULL,NULL),(482,'chsi','10426','青岛科技大学','0','1','','37',NULL,NULL,NULL),(483,'sch','10429','青岛理工大学','0','\r\n','https://yjsxt.qut.edu.cn/Open/Master/CjSignin.aspx','37',NULL,NULL,NULL),(484,'chsi','10435','青岛农业大学','0','1','','37',NULL,NULL,NULL),(485,'chsi','10446','曲阜师范大学','0','1','','37',NULL,NULL,NULL),(486,'chsi','10456','山东财经大学','0','1','','37',NULL,NULL,NULL),(487,'chsi','10422','山东大学','0','1','','37',NULL,NULL,NULL),(488,'chsi','10439','山东第一医科 \r\n大学','0','1','','37',NULL,NULL,NULL),(489,'chsi','83115','山东非金属材料研究所','0','1','','37',NULL,NULL,NULL),(490,'chsi','11688','山东工商学院','0','1','','37',NULL,NULL,NULL),(491,'chsi','10908','山东工艺美术学院','0','1','','37',NULL,NULL,NULL),(492,'chsi','10430','山东建筑大学','\r\n0','1','','37',NULL,NULL,NULL),(493,'chsi','11510','山东交通学院','0','0','','37',NULL,NULL,NULL),(494,'chsi','10424','山东科技大学','0','1','','37',NULL,NULL,NULL),(495,'chsi','10433','山东理工大学','0','1','','37',NULL,NULL,NULL),(496,'chsi','10434','山东农业大学','0','1','','37',NULL,NULL,NULL),(497,'chsi','10445','山东\r\n师范大学','0','1','','37',NULL,NULL,NULL),(498,'chsi','10457','山东体育学院','0','1','','37',NULL,NULL,NULL),(499,'chsi','10458','山东艺术学院','0','1','','37',NULL,NULL,NULL),(500,'chsi','14100','山东政法学院','0','1','','37',NULL,NULL,NULL),(501,'chsi','10441','山东中医药大学','0','1','','37',NULL,NULL,NULL),(502,'chsi','10438','潍坊医学院','0','1','','37',NULL,NULL,NULL),(503,'chsi','11066','烟台大学','0','1','','37',NULL,NULL,NULL),(504,'chsi','89637','中共山东省委党校(山东行政学院）','0','1','','37',NULL,NULL,NULL),(505,'chsi','10423','中国海洋大学','0','1','','37',NULL,NULL,NULL),(506,'','10425\r\n','中国石油大学(华东)','','','','37',NULL,NULL,NULL),(507,'chsi','85301','自然资源部第一海洋研究所','0','1','','37',NULL,NULL,NULL),(508,'chsi','10479','安阳师范学院','0','0','','41',NULL,NULL,NULL),(509,'chsi','10484','河南财经政法大学','0','0','','41',NULL,NULL,NULL),(510,'chsi','10475','河南大学','0','1','','41',NULL,NULL,NULL),(511,'chsi','10463','河南工业大学','0','1','','41',NULL,NULL,NULL),(512,'chsi','10464','河南科技大学','0','0','','41',NULL,NULL,NULL),(513,'chsi','10467','河南科技学院','0','1','','41',NULL,NULL,NULL),(514,'chsi','10460','河南理工大学','0','1','','41',NULL,NULL,NULL),(515,'chsi','10466','河南农业大学','0','1','','41',NULL,NULL,NULL),(516,'chsi','10476','河南师范大学','0','0','','41',NULL,NULL,NULL),(517,'chsi','10471','河南中医药大学','0','1','','41',NULL,NULL,NULL),(518,'chsi','10078','华北水利水电大学','0','1','','41',NULL,NULL,NULL),(519,'chsi','86214','洛阳船舶材料研究所','0','1','','\r\n41',NULL,NULL,NULL),(520,'chsi','10482','洛阳师范学院','0','0','','41',NULL,NULL,NULL),(521,'chsi','10481','南阳师范学院','0','0','','41',NULL,NULL,NULL),(522,'chsi','10472','新乡医学院','0','1','','41',NULL,NULL,NULL),(523,'chsi','91037','信息工程大学','0','1','','41',NULL,NULL,NULL),(524,'chsi','10477','信阳师范学院','0','1','','41',NULL,NULL,NULL),(525,'chsi','10459','郑州大学','0','1','','41',NULL,NULL,NULL),(526,'chsi','10485','郑州航空工业管理学院','0','0','','41',NULL,NULL,NULL),(527,'chsi','86213','郑州机电工程研究所','0','1','','41',NULL,NULL,NULL),(528,'chsi','82708','郑州机械研究所','0','1','','41',NULL,NULL,NULL),(529,'chsi','10462','郑州轻工业大学','0','1','','41',NULL,NULL,NULL),(530,'chsi','86601','郑州烟草研究院','0','1','','41',NULL,NULL,NULL),(531,'chsi','82606','中钢集团洛阳耐火材料研究院','0','1','','41',NULL,NULL,NULL),(532,'chsi','82908','中国航空研究院六一三研究所','0','0','','41',NULL,NULL,NULL),(533,'chsi','82907','中国空空导弹研究院','0','1','','41',NULL,NULL,NULL),(534,'chsi','10465','中原工学院','0','1','','41',NULL,NULL,NULL),(535,'chsi','10489','长江大学','0','1','','42',NULL,NULL,NULL),(536,'chsi','82305','长江科学院','0','1','','42',NULL,NULL,NULL),(537,'chsi','91016','海军工程大学','0','1','','42',NULL,NULL,NULL),(538,'chsi','10512','湖北\r\n大学','0','1','','42',NULL,NULL,NULL),(539,'chsi','10500','湖北工业大学','0','0','','42',NULL,NULL,NULL),(540,'chsi','11600','湖北经济学院','0','0','','42',NULL,NULL,NULL),(541,'chsi','10927','湖北科技学院','0','0','','42',NULL,NULL,NULL),(542,'chsi','10523','湖北美术学院','0','1','','42',NULL,NULL,NULL),(543,'chsi','10517','湖北民族大学','0','1','','42',NULL,NULL,NULL),(544,'chsi','10525','湖北汽车工业学院','0','1','','42',NULL,NULL,NULL),(545,'chsi','88701','湖北省社会科学\r\n院','0','1','','42',NULL,NULL,NULL),(546,'chsi','10513','湖北师范大学','0','1','','42',NULL,NULL,NULL),(547,'chsi','10519','湖北文理学院','0','1\r\n','','42',NULL,NULL,NULL),(548,'chsi','10929','湖北医药学院','0','1','','42',NULL,NULL,NULL),(549,'chsi','10507','湖北中医药大学','0','1','','42',NULL,NULL,NULL),(550,'chsi','86216','华中光电技术研究所','0','1','','42',NULL,NULL,NULL),(551,'','10487','华中科技大学','','','','42',NULL,NULL,NULL),(552,'\r\n','10504','华中农业大学','','','','42',NULL,NULL,NULL),(553,'chsi','10511','华中师范大学','0','1','','42',NULL,NULL,NULL),(554,'chsi','10514','黄冈师范学院','0','1','','42',NULL,NULL,NULL),(555,'chsi','91\r\n033','火箭军指挥学院','0','1','','42',NULL,NULL,NULL),(556,'chsi','11072','江汉大学','0','1','','42',NULL,NULL,NULL),(557,'chsi','91026','空军预警学院','0','1','','42',NULL,NULL,NULL),(558,'chsi','11075','三峡大学','0','1','','42',NULL,NULL,NULL),(559,'chsi','82709','武汉材料保护研究所','0','1','','4\r\n2',NULL,NULL,NULL),(560,'chsi','86217','武汉船舶通信研究所','0','1','','42',NULL,NULL,NULL),(561,'chsi','86215','武汉船用电力推进装置研究所','0','1','','4\r\n2',NULL,NULL,NULL),(562,'chsi','10486','武汉大学','0','1','','42',NULL,NULL,NULL),(563,'','86218','武汉第二船舶设计研究所','','','','42',NULL,NULL,NULL),(564,'chsi','10495','武汉\r\n纺织大学','0','1','','42',NULL,NULL,NULL),(565,'chsi','10490','武汉工程大学','0','1','','42',NULL,NULL,NULL),(566,'chsi','10488','武汉科技大学','0','0','','42',NULL,NULL,NULL),(567,'','10497','武汉理工大学','','','','42',NULL,NULL,NULL),(568,'chsi','10496','武汉轻工大学','0','1','','42',NULL,NULL,NULL),(569,'chsi','84506','\r\n武汉生物制品研究所','0','1','','42',NULL,NULL,NULL),(570,'','86202','武汉数字工程研究所','','','','42',NULL,NULL,NULL),(571,'chsi','10522','武汉体育学院','0','1','','42',NULL,NULL,NULL),(572,'chsi','11524','武汉音乐学院','0','1','','42',NULL,NULL,NULL),(573,'chsi','84011','武汉邮电科学研究院','0','0','','42',NULL,NULL,NULL),(574,'','82609','中钢集团武汉安全环保研究院','','','','42',NULL,NULL,NULL),(575,'','89642','中共湖北省委党校','','','','42',NULL,NULL,NULL),(576,'chsi','\r\n85404','中国地震局地震研究所','0','0','','42',NULL,NULL,NULL),(577,'chsi','10491','中国地质大学(武汉)','0','1','','42',NULL,NULL,NULL),(578,'','82961','中国航空研究院610所','','','','42',NULL,NULL,NULL),(579,'chsi','83258','中国航天科技集团公司第四研究院第四十二所','0','1','','42',NULL,NULL,NULL),(580,'','86203','中国舰船研究设计中心(701所)','','','','42',NULL,NULL,NULL),(581,'chsi','10520','中南财经政法大学','0','0','','42',NULL,NULL,NULL),(582,'chsi','1052\r\n4','中南民族大学','0','1','','42',NULL,NULL,NULL),(606,'','86404','长沙矿山研究院','','','','43',NULL,NULL,NULL),(607,'','82603','长沙矿冶研究院','','','','43',NULL,NULL,NULL),(608,'','10536','长沙理工大学','','','','43',NULL,NULL,NULL),(609,'','91002','国防科技大学\r\n','','','','43',NULL,NULL,NULL),(610,'','10546','衡阳师范学院','','','','43',NULL,NULL,NULL),(611,'','10532','湖南大学','','','','43',NULL,NULL,NULL),(612,'','11342','湖南\r\n工程学院','','','','43',NULL,NULL,NULL),(613,'','10554','湖南工商大学','','','','43',NULL,NULL,NULL),(614,'','11535','湖南工业大学','','','','43',NULL,NULL,NULL),(615,'','\r\n10534','湖南科技大学','','','','43',NULL,NULL,NULL),(616,'','10543','湖南理工学院','','','','43',NULL,NULL,NULL),(617,'chsi','10537','湖南农业大学','0','1','','43',NULL,NULL,NULL),(618,'','10553','湖南人文科技学院','','','','43',NULL,NULL,NULL),(619,'chsi','10542','湖南师范大学','0','1','','43',NULL,NULL,NULL),(620,'chsi','1054\r\n1','湖南中医药大学','0','1','','43',NULL,NULL,NULL),(621,'','10531','吉首大学','','','','43',NULL,NULL,NULL),(622,'','10555','南华大学','','','','4\r\n3',NULL,NULL,NULL),(623,'','10547','邵阳学院','','','','43',NULL,NULL,NULL),(624,'','10530','湘潭大学','','','','43',NULL,NULL,NULL),(625,'','89643','中共湖南省委党校','','','','43',NULL,NULL,NULL),(626,'','82925','中国航发湖南动力机械研究所','','','','43',NULL,NULL,NULL),(627,'','10533','中南大学','','','','43',NULL,NULL,NULL),(628,'','10538','中南林业科技大学','','','','43',NULL,NULL,NULL),(629,'chsi','11819','东莞理工学院','0','1','','44',NULL,NULL,NULL),(630,'chsi','11847','佛山科学技术学院','0','1','','44',NULL,NULL,NULL),(631,'chsi','10592','广东财经大学','0','1','','44',NULL,NULL,NULL),(632,'chsi','11845','广东工业大学','0','1','','44',NULL,NULL,NULL),(633,'chsi','10566','广东海洋大学','0','1','','44',NULL,NULL,NULL),(634,'chsi','10588','广东技术师范大学','0','1','','44',NULL,NULL,NULL),(635,'chsi','11540','广东金融学院','0','1','','44',NULL,NULL,NULL),(636,'chsi','88901','广东省社\r\n会科学院','0','1','','44',NULL,NULL,NULL),(637,'chsi','88911','广东省心血管病研究所','0','1','','44',NULL,NULL,NULL),(638,'sch','11846','广东外语外贸大学','0','','https://yz.gdufs.edu.cn/info/1014/2837.htm','44',NULL,NULL,NULL),(639,'chsi','10573','广东药科大学','0','1','','44',NULL,NULL,NULL),(640,'chsi','10571','广东医科大学','0','1','','44',NULL,NULL,NULL),(641,'chsi','11078','广州大学','0','1','','44',NULL,NULL,NULL),(642,'chsi','10586','广州美术学院','0','1','','44',NULL,NULL,NULL),(643,'chsi','10585','广州体育学院','0','1','','44',NULL,NULL,NULL),(644,'chsi','10570','广州医科大学','0','1','','44',NULL,NULL,NULL),(645,'chsi','10572','广州中医药大学','0','1','','44',NULL,NULL,NULL),(646,'chsi','10561','华南理工大学','0','0','','44',NULL,NULL,NULL),(647,'chsi','10564','华南农业大学','0','1','','44',NULL,NULL,NULL),(648,'chsi','10574','华南师范大学','0','1','','44',NULL,NULL,NULL),(649,'','10559','暨南大学','','','','44',NULL,NULL,NULL),(650,'chsi','14325','南方科技大学','0','1','','44',NULL,NULL,NULL),(651,'chsi','12121','南方医科大学','0','1','','44',NULL,NULL,NULL),(652,'chsi','10560','汕头大学','0','1','','44',NULL,NULL,NULL),(653,'chsi','10590','深圳大学','0','0','','44',NULL,NULL,NULL),(654,'chsi','11349','五邑大学','0','1','','44',NULL,NULL,NULL),(655,'chsi','10587','星海音乐学院','0','1','','44',NULL,NULL,NULL),(656,'chsi','89644','中共广东省委党校','0','0','','44',NULL,NULL,NULL),(657,'chsi','10558','中山大学','0','1','','44',NULL,NULL,NULL),(658,'chsi','11347','仲恺农业工程学院','0','0','','44',NULL,NULL,NULL),(659,'chsi','11607','北部湾大学','0','1','','45',NULL,NULL,NULL),(660,'chsi','11548','广西财经学院','0','1','','45',NULL,NULL,NULL),(661,'chsi','10593','广西大学','0','1','','45',NULL,NULL,NULL),(662,'chsi','1\r\n0594','广西科技大学','0','1','','45',NULL,NULL,NULL),(663,'chsi','10608','广西民族大学','0','1','','45',NULL,NULL,NULL),(664,'chsi','10602','广西师范大学','0','1','','45',NULL,NULL,NULL),(665,'chsi','10598','广西医科大学','0','1','','45',NULL,NULL,NULL),(666,'','10607','广西艺术学院','','','','45',NULL,NULL,NULL),(667,'chsi','10600','广西中医药大学','0','1','','45',NULL,NULL,NULL),(668,'chsi','10595','桂林电子科技大学','0','1','','45',NULL,NULL,NULL),(669,'chsi','10596','桂林理工大学','0','1','','45',NULL,NULL,NULL),(670,'chsi','10601','桂林医学院','0','1','','45',NULL,NULL,NULL),(671,'','91009','陆 \r\n军特种作战学院','','','','45',NULL,NULL,NULL),(672,'chsi','10603','南宁师范大学','0','1','','45',NULL,NULL,NULL),(673,'chsi','10599','右江民族医学院','0','1','','45',NULL,NULL,NULL),(674,'','10589','海南大学','','','','46',NULL,NULL,NULL),(675,'','11100','海南热带海洋学院','','','','46',NULL,NULL,NULL),(676,'','11658','海南师范大学','','','','46',NULL,NULL,NULL),(677,'','11810','海南 \r\n医学院','','','','46',NULL,NULL,NULL),(678,'','10611','重庆大学','','','','50',NULL,NULL,NULL),(679,'','11799','重庆工商大学','','','','50',NULL,NULL,NULL),(680,'','10618','重庆交通大学','','','','50',NULL,NULL,NULL),(681,'','11551','重庆科技 \r\n学院','','','','50',NULL,NULL,NULL),(682,'','11660','重庆理工大学','','','','50',NULL,NULL,NULL),(683,'','10643','重庆三峡学院','','','','50',NULL,NULL,NULL),(684,'','10637','重庆师范大学','','','','50',NULL,NULL,NULL),(685,'','10631','重庆医科大学','','','','50',NULL,NULL,NULL),(686,'','10617','重庆邮电大学','','','','50',NULL,NULL,NULL),(687,'','91012','陆军军医大学','','','','50',NULL,NULL,NULL),(688,'','91014','陆军勤务学院','','','','50',NULL,NULL,NULL),(689,'','10655','四川美术学院','','','','50',NULL,NULL,NULL),(690,'','10650','四川外国语大学','','','','50',NULL,NULL,NULL),(691,'','10635','西南大学','','','','5\r\n0',NULL,NULL,NULL),(692,'','10652','西南政法大学','','','','50',NULL,NULL,NULL),(693,'','89650','中共重庆市委党校','','','','50',NULL,NULL,NULL),(694,'chsi','11079','成都大学','0','0','','51',NULL,NULL,NULL),(695,'chsi','10616','成都理工大学','0','0','','51',NULL,NULL,NULL),(696,'','10653','成都体育学院','','','','51',NULL,NULL,NULL),(697,'chsi','10621\r\n','成都信息工程大学','0','1','','51',NULL,NULL,NULL),(698,'chsi','13705','成都医学院','0','1','','51',NULL,NULL,NULL),(699,'chsi','10633','成都中医药大学','0','1','','51',NULL,NULL,NULL),(700,'chsi','10634','川北医学院','0','0','','51',NULL,NULL,NULL),(701,'','84004','电信科学技术第五研究所','','','','51',NULL,NULL,NULL),(702,'','10614','电子科技大学','','','','51',NULL,NULL,NULL),(703,'chsi','82809','核工业西南物理研究院','0','1','','51',NULL,NULL,NULL),(704,'chsi','10639','绵阳师范学院','0','1','','51',NULL,NULL,NULL),(705,'sch','10610','四川大学','\r\n0','','https://yz.scu.edu.cn/score','51',NULL,NULL,NULL),(706,'chsi','12212','四川警察学院','0','1','','51',NULL,NULL,NULL),(707,'','10626','四川农业大学','','','','51',NULL,NULL,NULL),(708,'chsi','10622','四川轻化工大学','0','1','','51',NULL,NULL,NULL),(709,'chsi','89101','四川省社会科学院','0','1','','51',NULL,NULL,NULL),(710,'chsi','10636','四川 \r\n师范大学','0','1','','51',NULL,NULL,NULL),(711,'sch','10654','四川音乐学院','0','','http://cx.sceea.cn/','51',NULL,NULL,NULL),(712,'chsi','10623','西华大学','0','1','','51',NULL,NULL,NULL),(713,'chsi','10638','西华师范大学','0','1','','51',NULL,NULL,NULL),(714,'','10651','西南财经大学','','','','51',NULL,NULL,NULL),(715,'sch','83105','西南技术物理研究所','0','','http://cx.sceea.cn/','51',NULL,NULL,NULL),(716,'chsi','10613','西南交通大学','0','0','','51',NULL,NULL,NULL),(717,'','10619','西南科技大学','','','','51',NULL,NULL,NULL),(718,'chsi','10656','西南民族大学','0','1','','51',NULL,NULL,NULL),(719,'chsi','10615','西南石油大学','0','0','','51',NULL,NULL,NULL),(720,'sch','10632','西南医科大学','0','','http://yjs.swmu.edu.cn/','51',NULL,NULL,NULL),(721,'sch','83114','西南自动化研究所','0','','http://cx.sceea.cn/','51',NULL,NULL,NULL),(722,'chs\r\ni','89651','中共四川省委党校','0','1','','51',NULL,NULL,NULL),(723,'chsi','82910','中国航空研究院第六二四研究所','0','1','','51',NULL,NULL,NULL),(724,'chsi','82906','中国航空研究院第六一一研究所','0','1','','51',NULL,NULL,NULL),(725,'sch','82802','中国核动力研究设计院','0','','http://cx.sceea.cn','51',NULL,NULL,NULL),(726,'chsi','10\r\n624','中国民用航空飞行学院','0','1','','51',NULL,NULL,NULL),(727,'chsi','10976','贵阳学院','0','1','','52',NULL,NULL,NULL),(728,'chsi','10671','贵州财经大学','0','1','','52',NULL,NULL,NULL),(729,'chsi','10657','贵州大学','0','1','','52',NULL,NULL,NULL),(730,'chsi','10672','贵州民\r\n族大学','0','1','','52',NULL,NULL,NULL),(731,'chsi','10663','贵州师范大学','0','1','','52',NULL,NULL,NULL),(732,'chsi','10660','贵州医科大学','0\r\n','1','','52',NULL,NULL,NULL),(733,'chsi','10662','贵州中医药大学','0','0','','52',NULL,NULL,NULL),(734,'chsi','10670','黔南民族师范学院','0','1','','52',NULL,NULL,NULL),(735,'chsi','83286','中国航天科工集团第十研究院','0','1','','52',NULL,NULL,NULL),(736,'chsi','10661','遵义医科大学','0','1','','52',NULL,NULL,NULL),(737,'','10679','大理大学','','','','53',NULL,NULL,NULL),(738,'','86401','昆明贵金属研究所','','','','53',NULL,NULL,NULL),(739,'','10674','昆明理工大学','','','','53',NULL,NULL,NULL),(740,'','83104','昆明 \r\n物理研究所','','','','53',NULL,NULL,NULL),(741,'sch','11393','昆明学院','0','','https://www.ynzs.cn','53',NULL,NULL,NULL),(742,'','10678','昆明医科大学','','','','53',NULL,NULL,NULL),(743,'','10677','西南林业大学','','','','53',NULL,NULL,NULL),(744,'','10689','云南财经大学','','','','53',NULL,NULL,NULL),(745,'','\r\n10673','云南大学','','','','53',NULL,NULL,NULL),(746,'','11392','云南警官学院','','','','53',NULL,NULL,NULL),(747,'','10691','云南民族大学','','','','53',NULL,NULL,NULL),(748,'','10676','云南农业大学','','','','53',NULL,NULL,NULL),(749,'','10681','云南师范大学','','','','53',NULL,NULL,NULL),(750,'','10690','云南 \r\n艺术学院','','','','53',NULL,NULL,NULL),(751,'','10680','云南中医药大学','','','','53',NULL,NULL,NULL),(752,'','10696','西藏藏医药大学','','','','54',NULL,NULL,NULL),(753,'','10694','西藏大学','','','','54',NULL,NULL,NULL),(754,'','10695','西藏民族大学','','','','54',NULL,NULL,NULL),(755,'sch','10693','西藏农 \r\n牧学院','0','','http://zsks.edu.xizang.gov.cn/75/index.html','54',NULL,NULL,NULL),(756,'chsi','10721','宝鸡文理学院','0','1','','61',NULL,NULL,NULL),(757,'chsi','10710','长安大学','0','0','','61',NULL,NULL,NULL),(758,'','84003','电信科学技术第四研究所(西安)','','','','61',NULL,NULL,NULL),(759,'chsi','\r\n83256','航天动力技术研究院','0','1','','61',NULL,NULL,NULL),(760,'chsi','91034','火箭军工程大学','0','0','','61',NULL,NULL,NULL),(761,'chsi','91024','空军\r\n工程大学','0','1','','61',NULL,NULL,NULL),(762,'chsi','91030','空军军医大学','0','1','','61',NULL,NULL,NULL),(763,'chsi','10708','陕西科技大学','0','0','','61',NULL,NULL,NULL),(764,'chsi','10720','陕西理工大学','0','1','','61',NULL,NULL,NULL),(765,'chsi','10718','陕西师范大学','0','0','','61',NULL,NULL,NULL),(766,'chsi','83\r\n110','陕西应用物理化学研究所','0','1','','61',NULL,NULL,NULL),(767,'chsi','10716','陕西中医药大学','0','1','','61',NULL,NULL,NULL),(768,'chsi','91039','武\r\n警工程大学','0','0','','61',NULL,NULL,NULL),(769,'chsi','11560','西安财经大学','0','0','','61',NULL,NULL,NULL),(770,'chsi','83113','西安电子工程研究所（20\r\n6所）','0','1','','61',NULL,NULL,NULL),(771,'chsi','10701','西安电子科技大学','0','1','','61',NULL,NULL,NULL),(772,'chsi','10709','西安工程大学','0','0','','61',NULL,NULL,NULL),(773,'chsi','10702','西安工业大学','0','1','','61',NULL,NULL,NULL),(774,'','83233','西安航天精密机电研究所（航天16所）','\r\n','','','61',NULL,NULL,NULL),(775,'chsi','83109','西安机电信息技术研究所(212所)','0','1','','61',NULL,NULL,NULL),(776,'chsi','10703','西安建筑科技大学','0\r\n','1','','61',NULL,NULL,NULL),(777,'chsi','10698','西安交通大学','0','1','','61',NULL,NULL,NULL),(778,'chsi','83101','西安近代化学研究所(204所)','0','1','','\r\n61',NULL,NULL,NULL),(779,'','86212','西安精密机械研究所','','','','61',NULL,NULL,NULL),(780,'chsi','10704','西安科技大学','0','1','','61',NULL,NULL,NULL),(781,'chsi','10700','西\r\n安理工大学','0','1','','61',NULL,NULL,NULL),(782,'chsi','10729','西安美术学院','0','0','','61',NULL,NULL,NULL),(783,'chsi','82304','西安热工研究院有限公司\r\n','0','1','','61',NULL,NULL,NULL),(784,'chsi','10705','西安石油大学','0','1','','61',NULL,NULL,NULL),(785,'chsi','10727','西安体育学院','0','1','','61',NULL,NULL,NULL),(786,'chsi','10724','西安外国语大学','0','0','','61',NULL,NULL,NULL),(787,'chsi','83276','西安微电子技术研究所（航天771所）','0','\r\n1','','61',NULL,NULL,NULL),(788,'chsi','83112','西安现代控制技术研究所','0','1','','61',NULL,NULL,NULL),(789,'chsi','11840','西安医学院','0','1','','61',NULL,NULL,NULL),(790,'chsi','10728','西安音乐学院','0','1','','61',NULL,NULL,NULL),(791,'chsi','83103','西安应用光学研究所(205所)','0','1','','61',NULL,NULL,NULL),(792,'chsi','11664','西安邮电大学','0','0','','61',NULL,NULL,NULL),(793,'chsi','10697','西北大学','0','1','','61',NULL,NULL,NULL),(794,'chsi\r\n','10699','西北工业大学','0','1','','61',NULL,NULL,NULL),(795,'chsi','91103','西北核技术研究所','0','1','','61',NULL,NULL,NULL),(796,'chsi','83111','西北机电工程研究所(202所)','\r\n0','1','','61',NULL,NULL,NULL),(797,'chsi','10712','西北农林科技大学','0','0','','61',NULL,NULL,NULL),(798,'chsi','10726','西北政法大学','0','0','','61',NULL,NULL,NULL),(799,'chsi','12715','西京学院','0','0','','61',NULL,NULL,NULL),(800,'chsi','10719','延安大学','0','1','','61',NULL,NULL,NULL),(801,'chsi','11395','榆林学院','0','1','','61',NULL,NULL,NULL),(802,'chsi','89661','中共陕西省委党校','0','1','','61',NULL,NULL,NULL),(803,'','82911','中国飞行试验研究院','','','','61',NULL,NULL,NULL),(804,'chsi','82904','中国航空研究院603所','0','1','','61',NULL,NULL,NULL),(805,'','82936','中国航空研究院618所','','','','61',NULL,NULL,NULL),(806,'chsi','82909','\r\n中国航空研究院623所','0','1','','61',NULL,NULL,NULL),(807,'chsi','82912','中国航空研究院631所','0','1','','61',NULL,NULL,NULL),(808,'chsi','83278','中国航\r\n天科技集团有限公司第六研究院第十一研究所','0','1','','61',NULL,NULL,NULL),(809,'chsi','83269','中国航天科技集团有限公司第五研究院西安分院\r\n','0','1','','61',NULL,NULL,NULL),(810,'chsi','10733','甘肃农业大学','0','1','','62',NULL,NULL,NULL),(811,'chsi','11406','甘肃政法大学','0','1','','62',NULL,NULL,NULL),(812,'chsi','10735','甘肃中医药大学','0','0','','62\r\n',NULL,NULL,NULL),(813,'chsi','10741','兰州财经大学','0','1','','62',NULL,NULL,NULL),(814,'chsi','10730','兰州大学','0','1','','62',NULL,NULL,NULL),(815,'chsi','10732','兰州交通大学','0','1','','62',NULL,NULL,NULL),(816,'chsi','10731','兰州理工大学','0','1','','62',NULL,NULL,NULL),(817,'chsi','84507','兰州生物制品研究所\r\n','0','1','','62',NULL,NULL,NULL),(818,'','83505','天华化工机械及自动化研究设计院','','','','62',NULL,NULL,NULL),(819,'chsi','10739','天水师范学院','0','0','','62',NULL,NULL,NULL),(820,'chsi','10742','西北民族大学','0','1','','62',NULL,NULL,NULL),(821,'chsi','10736','西北师范大学','0','\r\n1','','62',NULL,NULL,NULL),(822,'chsi','85403','中国地震局兰州地震研究所','0','1','','62',NULL,NULL,NULL),(823,'chsi','83271','中国空间技术研究院510所','0','1','','62',NULL,NULL,NULL),(824,'chsi','10743','青海大学','0','1','','63',NULL,NULL,NULL),(825,'chsi','10748','青海民族大学','0','1','','63',NULL,NULL,NULL),(826,'chsi','10746','青海师范大学','0','1','','63',NULL,NULL,NULL),(827,'','11407','北方民族大学','','','','64',NULL,NULL,NULL),(828,'sch','10749','宁夏大学','0','','https://www.nxjyks.cn/website/xxcx/Xxcx_scoreQueryOut.do','64',NULL,NULL,NULL),(829,'','1\r\n0753','宁夏师范学院','','','','64',NULL,NULL,NULL),(830,'','10752','宁夏医科大学','','','','64',NULL,NULL,NULL),(831,'','10997','昌吉学院','','','','65',NULL,NULL,NULL),(832,'','10763','喀什大学','','','','65',NULL,NULL,NULL),(833,'','10759','石河子大学','','','','65',NULL,NULL,NULL),(834,'sch','10757','塔里木大学','0','','ht\r\ntp://www.xjzk.gov.cn','65',NULL,NULL,NULL),(835,'','10766','新疆财经大学','','','','65',NULL,NULL,NULL),(836,'chsi','10755','新疆大学','0','0','','65',NULL,NULL,NULL),(837,'','10758','新疆农业大学','','','','65',NULL,NULL,NULL),(838,'sc\r\nh','10762','新疆师范大学','0','','http://www.xjzk.gov.cn','65',NULL,NULL,NULL),(839,'','10760','新疆医科大学','','','','65',NULL,NULL,NULL),(840,'','10768','新疆艺术学院','','','','65',NULL,NULL,NULL),(841,'','10764','伊犁师范大学','','','','65',NULL,NULL,NULL);
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL DEFAULT '0' COMMENT '代码',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `score` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '分数',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores`
--

LOCK TABLES `scores` WRITE;
/*!40000 ALTER TABLE `scores` DISABLE KEYS */;
INSERT INTO `scores` VALUES (1,1,'1',0.00,NULL,NULL);
/*!40000 ALTER TABLE `scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '姓名',
  `apply_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '姓名',
  `id_card` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '证件号码',
  `ticket` varchar(18) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '准考证号',
  `province` tinyint(4) DEFAULT NULL COMMENT '报考省',
  `school` tinyint(4) DEFAULT NULL COMMENT '报考学校',
  `effect_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '查询有效时间',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'user_id',
  `memo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `score` text COLLATE utf8mb4_unicode_ci,
  `iskj` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否会计',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头部单位说明',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (4,'董文浩','41019841234','652901199808180817','561213213234732',NULL,NULL,'2022-02-21 06:03:15',0,'无',NULL,NULL,'101/思想政治理论/72&&204/英语二/61&&302/数学二/93&&906/传热学/103',0,''),(3,'张玉龙1','410198410281','410801199310285518','561213213211180',NULL,NULL,'2022-02-21 09:43:44',0,'无',NULL,NULL,'101/思想政治理论/78&&201/英语一/36&&754/西方音乐史（一）/90&&817/音\r\n乐综合理论/1551',0,''),(5,'罗舒怡','512595951','511321199705130041','105892006003645',NULL,NULL,'2022-02-25 07:56:35',0,'',NULL,NULL,'101/思想政治理论/75&&204/英语二/81&&396/经济类联考综合能力/108&&431/金融学综合/112',1,''),(6,'罗珺齐','4324967241','432524199804210021','115351100801027',NULL,NULL,'2022-02-21 06:03:14',0,' 无',NULL,NULL,'101/思想政治理论/44&&204/英语二/28&&302/数学二/109&&813/c语言/135',0,''),(7,'陈熙瀚','43249611','321284200003028034','115351100832658',NULL,NULL,'2022-02-21 06:03:13',0,'无',NULL,NULL,'101/思想政治理论/68&&4/英语二/61&&302/数学二/97&&807/自动控制原理/63',0,''),(8,'白金','142193638','140602199510251713','100042142107204',NULL,NULL,'2022-02-21 10:06:33',0,'无',NULL,NULL,'101/思想政治理论/51&&301/数学一/92&&201/英语一/52&&970/电路/93',0,''),(9,'刘建威','370664361','370602199802175217','101732243503142',NULL,NULL,'2022-02-20 05:13:38',0,'无',NULL,NULL,'101/思想政治理论/67&&204/英语二/74&&303/数学三/109&&435/保险专业基础/117',0,''),(10,'冯炜翔','445971387','441723199512210017','107129445132807',NULL,NULL,'2022-02-20 05:43:54',0,'无',NULL,NULL,'101/思想政治理论/75&&201/英语一/33&&398/法硕联考专业基础（非法学）/113&&498/法硕联考综\r\n合（非法学）/110',0,''),(11,'李叶枫','220799326','320482200005207615','101832215403760',NULL,NULL,'2022-02-21 11:28:23',0,'无',NULL,NULL,'101/思想政治理论/61&&201/英语（一）/78&&302/数学（二）/110&&979/数据结构和（操作系统或计算机网络二选一）/103',0,'吉林大学研究生招生办公室网址：https://zsb.jlu.edu.cn/'),(12,'陈宇','450799574','320923200010310411','102472450720871',NULL,NULL,'2022-02-20 13:58:12',0,'无',NULL,NULL,'101/思想政治理论/80&&201/英语一/84&&639/汉语言文学综合/62&&867/评论与写作/95',0,''),(13,'朱国坤','220595682','220402199910045010','101832215307848',NULL,NULL,'2022-02-21 09:10:12',0,'无',NULL,NULL,'101/思想政治理论/69&&201/英语一/33&&302/数学二/87&&966/数据结构和高级语言程序设计/123',0,''),(14,'沈霖玮','520287212','522101199708280420','106632000009252',NULL,NULL,'2022-02-21 08:00:45',0,'无',NULL,NULL,'101/思想政治理论/65&&204/英语二/57&&333/教育综合/97&&856/教育研究方法/101',0,'贵州师范大学2022年硕士研究生招生有关事宜请关注研究生院校网：https://yjsc.gzun.edu.cn/'),(17,'刘睿','233288098','230102199904096124','100032067109858',NULL,NULL,'2022-02-22 01:26:31',0,'无',NULL,NULL,'101/思想政治理论/77&&201/英语一/65&&398/法律硕士专业基础（非法学）/108&&498/法律硕士综合（\r\n非法学）/117',0,''),(16,'张泽',' 142493893','142622199804062915','104222104120131',NULL,NULL,'2022-02-22 00:59:07',0,'无',NULL,NULL,'101/思想政治理论/74&&201/英语一/52&&301/数学一/101&&884/机械设计基础/105',0,''),(18,'张萌芮','231299533','231083199909191028','102002211319633',NULL,NULL,'2022-02-22 01:28:21',0,'无',NULL,NULL,'101/思想政治理论/78&&204/英语（二）/41&&333/教育综合/123&&811/基础化学/118',0,''),(19,'刘睿','233288098','230102199904096124','100032067109858',NULL,NULL,'2022-02-22 01:38:09',0,'无',NULL,NULL,'101/思想政治理论/77&&201/英语一/65&&398/法律硕士专业基础（非法学）/108&&498/法律硕士综合（\r\n非法学）/117',0,''),(20,'余翔','41019841653','410105199412190053','100032101726034',NULL,NULL,'2022-02-22 08:23:18',0,'无',NULL,NULL,'101/思想政治理论/73&&201/英语一/68&&302/数学二/97&&828/经济学综合/52',0,''),(21,'申奥杰1','410662314','410882199901251516','107180245104302',NULL,NULL,'2022-02-23 03:10:08',0,'无',NULL,NULL,'101/思想政治理论/68&&201/英语二/71&&347/心理学专业综合/1570',0,''),(22,'赵林禄','410662334','107012131007515','107012131007515',NULL,NULL,'2022-02-23 02:54:44',0,'无',NULL,NULL,'101/思想政治理论/64&&201/英语(一)/36&&301/数学(一)/105&&834/数据结构、计算机组成原理/87',0,'');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'kaoyan'
--

--
-- Dumping routines for database 'kaoyan'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-28 11:00:37
